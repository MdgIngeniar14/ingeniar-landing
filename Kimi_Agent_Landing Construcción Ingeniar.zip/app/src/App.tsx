import { Calendar, Construction } from 'lucide-react';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center px-6 py-12">
      {/* Logo */}
      <div className="mb-8">
        <img 
          src="/logo.png" 
          alt="Ingeniar Consultoría" 
          className="w-48 md:w-64 h-auto"
        />
      </div>

      {/* Icono de construcción */}
      <div className="mb-6">
        <div className="w-20 h-20 rounded-full bg-brand-blue/10 flex items-center justify-center">
          <Construction className="w-10 h-10 text-brand-blue" />
        </div>
      </div>

      {/* Título principal */}
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-brand-blue text-center mb-4 font-lato">
        Sitio en Construcción
      </h1>

      {/* Subtítulo / Lema */}
      <p className="text-xl md:text-2xl text-gray-700 text-center mb-2 font-lato font-light">
        Transformamos organizaciones
      </p>
      <p className="text-lg md:text-xl text-brand-green text-center mb-8 font-lato">
        con ingenio y agilidad
      </p>

      {/* Descripción */}
      <p className="text-gray-600 text-center max-w-lg mb-10 text-base md:text-lg leading-relaxed">
        Estamos trabajando en algo extraordinario para ti. 
        Muy pronto podrás conocer todos nuestros servicios de consultoría 
        estratégica y transformación digital.
      </p>

      {/* Botón de agendar */}
      <a
        href="https://calendar.app.google/3MP79rpUyTkiPY3Z7"
        target="_blank"
        rel="noopener noreferrer"
        className="group inline-flex items-center gap-3 bg-brand-blue hover:bg-brand-blue/90 text-white font-semibold py-4 px-8 rounded-full transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-1"
      >
        <Calendar className="w-5 h-5" />
        <span>Agendar una reunión</span>
      </a>

      {/* Footer */}
      <div className="mt-16 text-center">
        <p className="text-gray-400 text-sm">
          © {new Date().getFullYear()} Ingeniar Consultoría. Todos los derechos reservados.
        </p>
      </div>
    </div>
  );
}

export default App;
